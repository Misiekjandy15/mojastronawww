const { shell } = require('electron'); // Importuj moduł shell

document.getElementById('open-website').addEventListener('click', () => {
    shell.openExternal('https://misiekjandy15.github.io/mojastronawww/'); // Adres URL do Twojej strony
});
